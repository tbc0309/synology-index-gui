#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#define _GNU_SOURCE
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define MAXLEN 102400
#define EXTRA 12
#define MAXINPUT (MAXLEN + EXTRA + 2)
#define CONFIGFILE "/var/packages/Vaultwarden/var/.env"

const char *base64char = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const char padding_char = '=';

// Base64编码
int base64_encode(const unsigned char *sourcedata, char *base64) {
    int i = 0, j = 0;
    unsigned char trans_index = 0;
    const int datalength = strlen((const char*)sourcedata);

    for (; i < datalength; i += 3) {
        trans_index = ((sourcedata[i] >> 2) & 0x3f);
        base64[j++] = base64char[(int)trans_index];

        trans_index = ((sourcedata[i] << 4) & 0x30);
        if (i + 1 < datalength) {
            trans_index |= ((sourcedata[i + 1] >> 4) & 0x0f);
            base64[j++] = base64char[(int)trans_index];
        } else {
            base64[j++] = base64char[(int)trans_index];
            base64[j++] = padding_char;
            base64[j++] = padding_char;
            break;
        }

        trans_index = ((sourcedata[i + 1] << 2) & 0x3c);
        if (i + 2 < datalength) {
            trans_index |= ((sourcedata[i + 2] >> 6) & 0x03);
            base64[j++] = base64char[(int)trans_index];
            trans_index = sourcedata[i + 2] & 0x3f;
            base64[j++] = base64char[(int)trans_index];
        } else {
            base64[j++] = base64char[(int)trans_index];
            base64[j++] = padding_char;
            break;
        }
    }

    base64[j] = '\0';
    return 0;
}

// 获取配置值
int get_conf_value(const char *file_path, const char *key_name, char *value, size_t value_size) {
    FILE *fp = fopen(file_path, "r");
    if (!fp) {
        fprintf(stderr, "打开配置文件出错: %s\n", file_path);
        return -1;
    }

    char *line = NULL;
    size_t len = 0;
    ssize_t read;

    while ((read = getline(&line, &len, fp)) != -1) {
        if (strncmp(line, key_name, strlen(key_name)) == 0 && line[strlen(key_name)] == '=') {
            snprintf(value, value_size, "%s", line + strlen(key_name) + 1);
            // 去掉换行符
            value[strcspn(value, "\r\n")] = '\0';
            free(line);
            fclose(fp);
            return 0;
        }
    }

    fprintf(stderr, "key: %s 不在配置文件中!\n", key_name);
    free(line);
    fclose(fp);
    return -1;
}

// 转码
void unencode(const char *src, const char *last, char *dest) {
    for (; src != last; src++, dest++) {
        if (*src == '+') {
            *dest = ' ';
        } else if (*src == '%') {
            int code;
            if (sscanf(src + 1, "%2x", &code) != 1) {
                code = '?';
            }
            *dest = (char)code;
            src += 2;
        } else {
            *dest = *src;
        }
    }
    *dest = '\n';
    *++dest = '\0';
}

// 获取Vaultwarden管理端口，检查证书是否启用
int GetWebPort() {
    char getport[4096] = {0};
    char checktlscon[4096] = {0};
    const char port_key[] = "ROCKET_PORT";
    const char tlscon_key[] = "ROCKET_TLS";

    if (get_conf_value(CONFIGFILE, port_key, getport, sizeof(getport)) == 0) {
        printf("var vaultwardenwebport = '%s';\n", getport);
    }

    if (get_conf_value(CONFIGFILE, tlscon_key, checktlscon, sizeof(checktlscon)) == 0 && strlen(checktlscon) > 0) {
        printf("var url = \"https:\" + \"//\" + domain + \":\" + vaultwardenwebport;\n");
    } else {
        printf("var url = prol + \"//\" + domain + \":\" + vaultwardenwebport;\n");
    }

    return 0;
}

/**
 * 检查用户是否登录。 
 * 
 * 如果用户已登录，则将用户名输入“ user”。
 * 
 * @param user    获取用户名的缓冲区
 * @param bufsize 用户的缓冲区大小
 * 
 * @return 0: 用户未登录或错误
 *         1: 用户登录。用户名写入给定的“用户”
 */
int IsUserLogin(char *user, int bufsize)
{
    FILE *fp = NULL;
    char buf[1024];
    int login = 0;

    bzero(user, bufsize);

    fp = popen("/usr/syno/synoman/webman/modules/authenticate.cgi", "r");
    if (!fp) {
        return 0;
    }
    bzero(buf, sizeof(buf));
    fread(buf, 1024, 1, fp);


    if (strlen(buf) > 0) {
        snprintf(user, bufsize, "%s", buf);
        login = 1;
    }
    pclose(fp);

    return login;
}

// 配置文件内容
int Content() {
    char *lenstr = getenv("CONTENT_LENGTH");
    if (!lenstr) {
        fprintf(stderr, "CONTENT_LENGTH 环境变量未设置!\n");
        return -1;
    }

    long len;
    if (sscanf(lenstr, "%ld", &len) != 1 || len > MAXLEN) {
        FILE *fp = fopen(CONFIGFILE, "r");
        if (!fp) {
            printf("抱歉，没有找到Vaultwarden配置文件。</p>");
            return -1;
        }

        char data[MAXLEN];
        while (fgets(data, sizeof(data), fp)) {
            printf("%s", data);
        }
        fclose(fp);
    } else {
        char *input = malloc(len + 1);
        char *data = malloc(MAXINPUT);
        if (!input || !data) {
            fprintf(stderr, "内存分配失败!\n");
            if (input) free(input);
            if (data) free(data);
            return -1;
        }

        if (fgets(input, len + 1, stdin) == NULL) {
            fprintf(stderr, "读取标准输入失败!\n");
            free(input);
            free(data);
            return -1;
        }

        char *tmps = strstr(input, "Submit");
        char *tmpc = strtok(input, "&");

        if (tmps != NULL) {
            FILE *fp = fopen(CONFIGFILE, "w");
            if (!fp) {
                fprintf(stderr, "无法打开配置文件写入!\n");
                free(input);
                free(data);
                return -1;
            }

            unencode(tmpc + EXTRA, tmpc + len, data);

            // 替换\r\n为\n
            char *pos;
            while ((pos = strstr(data, "\r\n")) != NULL) {
                *pos = '\n';
                memmove(pos + 1, pos + 2, strlen(pos + 2) + 1);
            }

            fputs(data, fp);
            fclose(fp);
            system("/var/packages/Vaultwarden/target/restart");

            // 读取并输出新的配置内容
            fp = fopen(CONFIGFILE, "r");
            if (fp) {
                while (fgets(data, MAXLEN, fp) != NULL) {
                    printf("%s", data);
                }
                fclose(fp);
            }
        } else {
            FILE *fp = fopen(CONFIGFILE, "r");
            if (fp) {
                while (fgets(data, MAXLEN, fp) != NULL) {
                    printf("%s", data);
                }
                fclose(fp);
            }
        }

        free(input);
        free(data);
    }
    return 0;
}

// Vaultwarden全局配置页面
int WebPage() {
    printf ("<!DOCTYPE html>\n");
    printf ("<html lang=\"en\">\n");
    printf ("<head>\n");
    printf ("<meta charset=\"UTF-8\">\n");
    printf ("<title>Vaultwarden</title>\n");
    printf ("<link rel=\"stylesheet\" href=\"styles/codemirror.min.css\">\n");
    printf ("<script src=\"js/codemirror.min.js\"></script>\n");
    printf ("<script src=\"js/mode/shell/shell.min.js\"></script>\n");
    printf ("<style>\n");
    printf ("body, html {height: 100%; margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; justify-content: center; align-items: center; flex-direction: column;}\n");
    printf ("#container {text-align: center; padding: 20px; box-sizing: border-box; max-height: 100vh; overflow: hidden;}\n");
    printf ("img {height: 70px;}\n");
    printf (".des {color: #555; font-size: 1.2em; margin-bottom: 20px;}\n");
    printf ("a {text-decoration: none;  color: #1E90FF; font-weight: bold;}\n");
    printf ("a:hover {color: #5599FF;}\n");
    printf (".button {width: 40%;  height: 40px;  border-width: 0px;  border-radius: 3px;  background: #1E90FF;  cursor: pointer;  outline: none;  font-family: Microsoft YaHei;  color: white;  font-size: 22px; margin: 5px; margin-top: 10px;}\n");
    printf (".button:hover {background: #5599FF; }\n");
    printf (".CodeMirror {height: calc(100vh - 260px); font-family: Microsoft YaHei;  font-size: 12px; border: 1px solid #ccc; border-radius: 5px; margin: 0 auto;  text-align: left;}\n");
    printf ("</style>\n");
    printf ("</head>\n");
    printf ("<body>\n");
    printf ("<div id=\"container\">\n");
    printf ("<img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABEYAAAEACAYAAAC+gXPDAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3BpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDkuMC1jMDAwIDc5LjE3MWMyN2ZhYiwgMjAyMi8wOC8xNi0yMjozNTo0MSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDoxZjJiOTdlNy0zYjFkLTQ5YzItYjBmZi03N2M5YmUxOTZmNGEiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MTcxOTYyN0E5RjkwMTFFRDg1RDNGODFBMEM4NEM1OTkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MTcxOTYyNzk5RjkwMTFFRDg1RDNGODFBMEM4NEM1OTkiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDIyLjMgKE1hY2ludG9zaCkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDoxRDM3QzM3OTBCOTExMUVDOTMxMDkzQzJBOThFODAwNSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDoxRDM3QzM3QTBCOTExMUVDOTMxMDkzQzJBOThFODAwNSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pt+Aa8YAAGeGSURBVHja7J0HgBy11cefZvfu3HuhN5veW+id0HsNxdR8SegJhJCQkEIntBRICAECGEiCacZgQjcdTA2EbsB029hg3K7tjr73bmU4zO3daHaKZvb/I8rcnadITxqN9PTek9JaEwAAAAAAAAAAAEA94kEEAAAAAAAAAAAAqFeK1f5B/c78IKqTd/5Hg9pHUhPNJl30yFN6FPm0rya1Dv/rYpwKECWoQzT/9xkp/2W/TPco5b3keVSSP/v84ng+v0dadZz4yY3LQ1oAAAAAAAAA4CBFiykgz/JoVaXpUq3VDh2/AVDvdLwFhf28gj6Tf3iG35PT+W8PQTAAAAAAAAAAkA28bv9FktiCeCWe6+k9qeC9xr/tSFCKANCJr+L0bKQVTeS34xTIBAAAAAAAAACyQVXFiFfyO5JqJxpYKp7TWJj3b4gLgB5p0lpdpEiP558LSnnkefA0AwAAAAAAAABXqepKs8Sn0zqO7e1thxb9vqeXvDLBUASAwOzGr8sxfrl8mdY+pAEAAAAAAAAAjlLVYqS8oJl0S8uSXnvpwpJEkYRSBAC7d6ug/jx//uzR099/F9IAAAAAAAAAAGcnb1UoKqKy7x/re2oxiAmAEGhNxV69zugzfBhkAQAAAAAAAACOUl0x0rtRIiTsBBEBEA6tNfXq0+ew4YsNhzAAAAAAAAAAwFGqKkY+/OBDUspbDyICIDx+uUyt7S07QhIAAAAAAAAA4CZVFSONhWJ/DfkAUDOtH/bdHVIAAAAAAAAAADepqhgZvNhiq+pyGRICoEZUQ3kgpAAAAAAAAAAAblJVMVJqayuSwk40ANRKw+LNeJEAAAAAAAAAwFGqKkZ4JudDPADUjt9WgBAAAAAAAAAAwFE8iAAAAAAAAAAAAAD1ChQjAAAAAAAAAAAAqFugGAEAAAAAAAAAAEDdAsUIAAAAAAAAAAAA6hYoRgAAAAAAAAAAAFC3QDECAAAAAAAAAACAugWKEQAAAAAAAAAAANQtUIwAAAAAAAAAAACgboFiBAAAAAAAAAAAAHULFCMAAAAAAAAAAACoW6AYAQAAAAAAAAAAQN0CxQgAAAAAAAAAAADqFihGAAAAAAAAAAAAULdAMQIAAAAAAAAAAIC6pQgRZBtfF7bxVLkJkrBiKKfLOA2GKAAAAAAAAACgvoFiJONo8iZp/n9FPoQRnCGcFhAUIwAAAAAAAABQ98CVJvNosRohrVGVFvQmKAUBAAAAAAAAABAUIzlBk08FsR6BKAAAAAAAAAAAAAswk84NYjnidViPAAAAAAAAAAAAIBhQjOQMsRqB5QgAAAAAAAAAABAMzKBzh4k5gqoFAAAAAAAAAAB6BLPnXFJRjvgIyAoAAAAAAAAAAHQLZs65RTbxheUIAAAAAAAAAADQHZg155rOW/lqiAMAAAAAAAAAAFgEKEZyz8KtfLFbDQAAAAAAAAAAsChQjNQF2MoXAAAAAAAAAADoiiJEUD9UtvLVpMiHMIAVSikIAdQlI8dM6cOHnThtzGkNTstw6sdpIKcFnOZxmsnpf5xe4DRx+tjRH0JyAAAAMva9k8HeSpxGmD9N5+/ZW5AMyOzcV9uFkoBipL6aR4fViMfdnqKyTHchEgAA6HqA2MCH0zidwmlQldMW/l0Gkpsu7Gj52lvkOihIAAAAZOB712i+dSdyWmyRf/uYD3/gdCl/08qQFsgzcKWpOxZu5Qu3GgAAqDJI7M2H/3A6i6orRaohGuf9OT3P91kT0gQAAODw967BfO/OpUWUIoYlOV3I6XpIC+QdKEbqEmzlCwAA3SCrY9vWeI/hnCbyoHMAxAkAAMBRxDJymwDnHczfswMhLpBnMDOuWyoBWXWH5Qi28gUAAIEHfivz4f8iut1SnE6FVAEAADj4vetn+Y06HVIDeQaKkTrHJ4WtfAEA4Gv2oWgDMB0EkQIAAHCQ7TnZWDWuNXLMlGUhNpBXoBgBFcuRjqYAyxEAQN2zecT3G8UDycUhVgAAAI4RJg7WGhAbyCtQjIAOKsoRWI4AAOqeETHccymIFQAAgGMMDXHNEIgN5BUoRsBXfG05AgAAdUtDDPfsC7ECAADIAVhFBbkFs2DwDSoBWeFWAwAAAAAAAACgPoBiBHwLn+BWAwAAAAAAAACgPoBiBHTJ15YjAAAAAAAAAABAfsHMF1TF77AaURAEAAAAAAAAAIDcAsUIqIoinxBrBAAAAAAAAABAnoFiBFRFqTKEAAAAAAAAAAAg10AxArpuGMqHEw0AAAAAAAAAgPzPfyEC0BUVNxoAAAAAAAAAACDfFCECsCgKcUUAACAXjBwzZUk+bMlpdU5LcBrAqb/5/s81aTandzg9z+np6WNHt0NyAAAAAKgnoBgB38JDbBEAAMg0I8dM2YQPZ3Haluy2F/ucr72cj+dOHzu6BZIEAAAAQF3MgSEC8I0GoWAtAgAAWWbkmClj+PAYp+3Ifs/1IZzO4HQ73wehpgAAAABQH/NgiAB0BrFFAAAgu4wcM2UFPvydU6HGW+3EaT9IFAAAAAD1ABQj4OvG0GEtAosRAADIMKdyaoroXsdCnAAAAACoi7kwRAAWogixRQAAIKuMHDNFrET2jfCWW/E9B0KyAAAAAMg7UIyASkNAbBEAAMg6G3AaHuH9JMbImhArAAAAAHI/H4YIQGX0i9giAACQcVaP4Z7LQqwAAAAAyDtQjADylChFYDECAAAZZ5UY7tkfYgUAAABA7ufEEAFQUIoAAEAe6BfDPXtBrAAAAADIO1CM1DkVpQgUIwAAkAP6QAQAAAAAAPZAMVLvDUBhJxoAAAAAAAAAAHU8L4YI6rjysRMNAAAAAAAAAIB6nxtDBPULdqIBAAAAAAAAAFDvQDFSpyC2CAAAAAAAAAAAAMVI/VY8YosAAAAAAAAAAABUhAjqD0/BhQZkj5Fjpgzig6TenJrMn0ucPps+dvR0SAgAAAAAAAAQBihG6pAQsUVkMrotp404rWYmozM4Pc/pZk6zIVUQFSPHTFmcD5tw2pjTqpyWN6lPN9e08+ENTi9yeoTTfdPHjv4I0gQAAACAw2OeAh/6cxpgxjm9OLVwmkOVhZ92SCn2OmjkQ2+W9ZeQRiLtXWQ9z8X8QTFSO77pvP7YaeImndienFZ3LbMhrEVWkUkmp6Wr/PtPOX2f02OEoCUgXCcp/dBWnPbitCtVlCC2NHBa06TDzH2lTV7D6SbugNsizO9KfNiQ07JmILNQUfgWp2f4WV8kJLcl+bAep1FUUV5K/zOX0+ecXuf0Eufl8wy3iTU4rc9puClfK1WUsO9wepbL9ineHgBAxH3PSD6M5rSCSYM5DaSKpeLCCes80+e/a/qjFzChinUSJYslfU0dNBtlQVa/bTK+2ZQqC42jTVrOjGG6oszXfMjHNzk9zelJTo9w+VvROqzlvgGntTitaMaZi5nxRe9O55GZy8wyY6n3Ob3H6X8ypjJjjxZItEd59+PD5mYMt74ZL8s8ciiZMB5G1gv70084yWLmVE6vUGXh/eU02rnSuuu57OJjpmyslXoK1dstH3M6g9Pt9G2riVFGobBCnBko66KyU4yUTeDVQEgDftwoR3pCXoAnMlJvS5qXbmQSD/M13Thj7KhDs9zQlVKR35M7xbX58ENO3zODz7iQCfS5nK7gTrYUMq8yaPkRpxPNQKZqdXN6mNMf+VkTYpBZbyOzwzmt08Pp8qJPoq+VQ8770HH5ZMDyk4BtQt7hq6R8ESu+ZPCzdsRF24bzOKmGPMngbU3TJ/ft5lRRUm8Wcd7/ab5ltbKAKoo7+Va+aTuxYRlI2cVyURSTopCUBYnnOD0Y9r12oL3LAHE7Tt/h1M8MDO/m8kzN8IBYyrQNVZTHg0y9i/JgEpfrYwfzuy4ftqaKleLmZhJuizYT13s5TTBlLUecT1EUb2HGLzKZkFnF/fycWTHLRxTuW5kJ5RCjmHjPTM6nxvA8GZftbupkAzOG7kppIEqpsZwudVkpxeURt98dOO3PafuQ7WtRZCI5kdPVpg3oGvL3Bz6cZHnZkfzMax3vhxbKfS8j92UiurVM1GVufBenW7PQV3fxDi8wCh95h9+L8Dli9XSgaevy/jZGIOvHTVsfz3l9J8xNquk5oBiJB/lQvdrNv69gBgTOKEYKymr8KI375oDn3mU+ZlCMQDHSU+cpEzdRKO6YcDHeMB/0py3zK+/x7eajYoN05mOiWtnifMig/QaqaN5tecmU/SVHP9wy8P0tp1Op+spZNaYYOT8dUV6cUYxwXnY3clkvh9/P1zjdxOmyniY2LAeRwWlUWbHvqv4P4XtMzpgCQdwEx9G3LUtlQv1neReypvDhMokyRCZMq3U1XOH0N07H1zKRiyifG5vxzV4Uz+KVKLj+Ydr2jBrzKvn7O1WUgl3JVP7tZ/ycuRHLSBRcP+b0K+paSS11eJupz2kRPG8nPpxgxgUFi0tlJX/TqMsfQXlE0fYj08YGxPiot6my8HNDmP4ib4oRLo/0PcfImIAqll5xIu+ALIRdZibuvmOyCPIO/5vTsbVYOvNzVubDKfIdpm5c3iNA3ORFGfhvm8UwKEaSQ1bRDg5w3l9N5+iEYqSoSjb+LjatSTTY/aEYgWKkm85T5H6pGZCmhXy4zpHJZpCPmIl38qxpM2GQQdtm/Kw5NcpOBosTQigNOiMrfbtxXh5y7OPdy5Rt+xpuI+6L+3PZxudFMcL5ON5MkPPOVKn7aqtBLIfvm8lfT217S77HcxlRICxj+pUR3Zx2JZfnhxlSioiyQfqW3j2cehKX608p5E/ydYRM5KsobuJgvpk0nRfGqsFYir0Y4PsjSuEtolSk8bOv5MP/BThVLGXW5Wc3h3zOlny4kCpWU2G5nJ9/vCPvgSizf0kVV5kkecNMcB+uR8UIl0MsaH9LlTAGaSDuy7Lgd1vait8Q73Co/oPvL9bTZ3M6QKYJCRZNXMt+w2lskDzbKkawXW94zg543q9cyrRF8zjDVkeDJgG66UCPpMoK8f4pZ8UzbfsuY17YXZ5l1epfNShFBLEqu57vpWqQ3TCqrKw31Fh2mRjcyvdbwrHm8ccalSJkZHMzl239nLwvopC7oE66h+VM3XldyEHq9ZyAbfsGE0AvC/y9B6WI8AMuzy4Zaa/iBnRzAKWI8EvTtyaVtyKn46jievGXBJUigri9iaXTG5yH/UJcf2nA748opX4Socw2CTihEmS1+MgQzxjKSb5rj9SoFBGO7ul7nkA7W5fTo/zjnSkoRQRxeX+I8/B3Tn3raGw5kpO4C7+QolJEEAvAWzg9atze0paLzTss/cdBFvfuw+lCM6Y/MGGliCCxSqTOX+J8bBDHJAGEI2gnPMsM/FPH0o3mcMvbP4kmAap0oDeYTmyAQ1nbmdODnLfuTC3FHHPLCJ4lH+sxNVx/LFX8QqNAfP5Pdqh9yCTlBxHdTibFl+Tk1TmC4jVJdQ1xFepKCbBhAAVC5wnaYRnoEyWmyA4BTz+/FqVqgpxI1QO0L4rU55oJyVrcNv9LFauNxVKUjzx7HOfnKmO5EiTvohD5nsUzftyVcjEkthauu1jWi7gFvWwzGesBsTpcJ6X3uYmTKLHFAmwLB95FsbCbbFz18j6+PIqMi3QKk/NqiMvzi5y3M5JUAEfwDu9l0adKcFTZeKMhZVmLG+rTnKfzTMB+KEZS5lmLc8UU0s9Q2VY0EygoRkAtHy1Z9ZYVlEMczaJoySd0tdJkAnf9OsJnnVPDR3LziMu9o0N1sHPE99uS5Tw4B6/PTnXYZXQ1kBsVYlLgOj+1OFcUCDu4XBjTr51gedmgmPPUYFY0ZWey1RwS19GcnuC8BVHSiBWdzTdDLAGjWqm2VTKMsqgbUfTfZ/IbJUNTaPsyVhY3hJ9Z1lXcrGYmjFvndGw5hNMdVIk3McjBLMok/UxODwd81+NgnRBtpjuZK04/p4qF1woOyVreO8nXgyZAe81AMVIbQYMgSpyBLLmaSNR/28nF9WgOoFMnurwZlLru2rCF+bguikxGhkf4nKWoEqU7lDgjLrNLrjRLZ+SeSbMW1R9dvR/tlvfYyMTvcLVfXDKEouPIDNSb7eB/QYwyFoW87GQgCigXrW1kF5ynjH9+d6wY4t5RTVj6WZ4/JGDdnM+Hy2NSIsxM+F2W9/hZSslSJQBioXsf53OPnI0tRd6y2LxnBrIr48vnzA6MSRPZO2ys3MTt7TxySwHYGbHuFqXzUrXeCIqR2tgq4HkS6DPV6PKyTa8Fe1u2DdGYf4LmAEwnKh2TBAAblZEsf4/zfOIif4vjQ7ZuyOuiDuRVyHkT9DL+/siqxyCqP0aarTo7E2ZXt70dLuO+IdrnHkHdL1JinxDXvB3Tu7Ommax+x/G2vhynST0oR/qFuG9U/YbtN6cpQN1IvJTTYpTpBwn20eIaK7vODXS8nYmrwy2c331zMrbcTSa/FN3Wu0kgynCJO7JNws+N5B027ub/ITu3vrQQd9qHTdDq+hxAOoCNb/xvMjSpONrifNG4SIT5EpoDMG4MD1K4LWXT5Pec91U6/T4shmcsgRYCAtC/jsu+aL8hcQjaLO/hsmJkrxDXiFLEySCsJv6J7Yr0W7VsDdlNXiTg5WNUW7DspCdMDxoLl7yPC8St4McxPuI5blMfJ1QWiT0mFtJZWWAQ5cg/Od/fzXgbEpdscZ/JYuwtsd6528TnyJLMRSkibm9bZijbomy+07jDh54Eg/CIqWPQVXHxd52ZgTLZDtxkgPNPNAVggh9JVO6VMph96USvjjnQIfpbEIR6Vox8w0eYJzutZB+/aouofI0j7h+H1DDA3MvR+hJXSVvT5YdikO16ZgA/MGPtXVa+78rzLiJcNllAPCPGR0gfcWJCZTmYKq5AWWOh5cgaGW1DohTJkjKqK3qbCfuqGZG5jIlvJ/et77pC4geG3hK+SKAWJLq6RM0Pau4rJp47p5FRi9me7Xaqd6IZAINsYb1thvO/KVXMBaHoA2mi67jsXa3y3EV28XlEASlWDP9wrGy71TCwF3eaxuljR7c5VqYwCpu7Ix7ASzwrMfVOYtczsZCdx2kOVVauB0UwWROlzhVU285lrk6uRBF4WUy39029n8HvxQsJlEVcIa6leOLWtFDFvUzSW5zmd2pnfU07E2WvLMZuQMF36uqMvB+3yZb2LK+5GWpDEoj8OopuYWk6Vdz/Jfbje5ymGXmLTPp3SmLJJa4Z65oUhVJGlOPjuUwbch186bjor+RUi/tPM6cpnD42Mp9r+s8G06bFbVaU6itQPFZAst39XSznCVCMJI9oMv8V8Nxb0lKMWLC75fn/QhMAZvu903JQlLO5LONQoyBF5kEE32A8p4tCTNhdU4zUYvUhk5ptzUQwy2WSCcj9EX53ZAIjipbhEZdLJqoSwHUSp9cXTliNBdOieZC6GWUUHKII2JXsd0g5lO/zMN//mhyNCUaY8WFUW3q2mnp40dTLRJbXtITKshwfbqVotyd9htM9nB6Qn7ksJYv8yDalEtvncLKL5SaKlSvI3Z0CFy2nxAy6OQKlhMSfkXfrNpbzKyHyMcjM3UTete7qJ3VwFdkvQicp9+P5cJjlZR9SxWpP3k0xApjCsi4HeJbUrbixb2Hmn7IbV2NERfkz31/er2YoRpJlE4tzZZsjcacZ5mhZ5KW3DfJ2P5pA3StFJEjc1TkpjmivD0WtghT5vI7LPmvRP/Dgagr3Ma/yj6tb3GcHcU/ga+c70kf2jmBAvY9LihEu0yjLOhHu6kq5UAN/5xSVaXq7mfzK6vQkzmdLkIv4vDlmsi7pauNSKjFhJKaGzYrrH/jae5OKlZEAopgMEz9FLEEmc3rKTLBkVf99TtNYNjqFdt5gJudRbAPfYsZKf+ayvBn2Jnyt9Ievct7OocruLGKtG3Rb6oNl8YfvcYfj40pxi7uNanMtFYsFceO6mcvr1yDv2VSxJJZYLSJnkXstiu79+D6H832vc1DusvHARRbteaxJj4d5P43y5FWTrjCBU79v+s8RNRZHYpbJgu1voRhJFlkZaKBg2wqKy80bnDZPMoOqwzK7x/YqJswSdNXGXO1cVD8wnc5yOSrPKVQJIAtA4shEiwcHLivQ46TaZGG85SS8l1FE3OZIuSTwYa3mwntJ4Mcgq3AJEWZiEJk1HsviCD4cGJFC5K+cLmDZfhLB+ysr/+JiLPEEtqaKr/uaAS6VCeDl5G48GZu6kUU224DB4t4gE0VZ1Z/hUHFk44QNI7iPxMj4RRRtrFNbk8n+7SxvcRc4mdNZFGy1/S+yks7Xu2ydKK4co0NeKxMe2Rr6zKAKTguZv8aHvVl+YhkmSq6RIW91Cd/jHpfaulHqXkM97zLVZvq1C6POP9/vMz6cx3mRvvB0TqdSbW5Upy122DuXTbt+VOAYnwgGGA1TLc7dwtEyLGWZNxlM/AdVX99w5yU+mCfmrFgSoGxz1C5Ikf/WYZk/7GaQFWZ106UJZhR5kZW0zTJcJrHemRjRd0d2dPlDBLeaJEoLbncnRTlh7TTIn2Qm1b+nYLGD9jRuqVkeEywmkz6LS6RNbM6y2oTTFY5NFMU96uc13kba1fZcrsPjaGOmnZU4SRuTQJmvBbhELHl+4XAbElefA8KKg9NOLI/To1aKLCJzceFbh+yDgy9E4o2c75joZcel9Xo4RxYNV+fynxrnuyoLRJzk3ROru09ruJUskhxvcwEUI9EgDXwji/PfcbAM+4XofN5D1dc9YjXUkMNyrY+qBSlSj0rn7qwJnqNKEDcbdjNm8GkP8sWHeveIbrevIxMXUdJsanmZuNE0R5QFUYrUsgONrLTLauR2tbg0BBzgt3ISc27xnQ/iJndxzLujxc1lZkzcE+LmsCvLRtITDk7OZX4klkS1xLeQODXrcfkSsUDl54hCXXbkuCfA6SdxGYc5KHfpW8LuKCLll+Cy9yUkb4lxsx2nCSFvcYRxXXEBsTT6TTf/LpZwoqjYQdxbk8oUP+tRqiza1zJvPn6xw94JHCYCipFoEI2UTVDVR5LMnKcCWd7aamdFMfIRqr5+4Q5dInXvk9LjZfVxElWCWEln/RNOP6SKP6FsjS0rzJ+glkBGuZGCuWfmhTYzCak2OJLV9vGW95SYAFs6UDax8ohqArK3I5Pm3UOMHyNxo+Hyy0RkvxpuIcqZ3bhNnVdL3IEQA/yHzKT1/R5OlVXoHbP4EnPdyDg4iPJOXGbWYZlMdLg4Enyylq1KJ5hJ5PQkM212nJFduW7q4VTZGeSnDspdxm9DQlwncWm2SjpGj7FKkf4ozGKG9OW/c0TuojgY2k2fuSeX9YIk+8xOMhalSFDFclcMtflmIMZIdEgApHMCDmYlYNhRyWRL3jtNPewwJv+4nuWNz0GV1z2nJ/y8uWbCKB/8Z4JsXWkCBEr07/+jSmBVAJyH2/an3Hb/wj+eVCdF/lmAVSiJF3Ks5X3F3SPteEFRuvQsTZXtOp/NWJlaKAIrKKMUurBGpYi4NTyZ0nv9NpdB3DQfo+7jcomy/6WMKUVkPtFT0EaZVEmcnCsdL4tMEs+q4RayKcF+aW2vLa41XAZR7EisiO4UVT+gSmBZV+QufdvhIS6V7Zp3SGsLXKlnzruMMyVOjm1AanGfW83ELnGRVPvMTjKeynKSBfwHQt5CNlUYG+REWIxEh2j5gyqaZMuxN5PIlFI+Bdh2/QrL20oQm9tR5fULd1CiZEjKWmSBGaQswZ2jDKoeCzrgEE0zJ/HjlFgoRxKsnECGlAUUYbBKR5EVoB/wO/rHAOdO4vSZ7QTeAQuLPSO+X6ruNLLbD1WCydowMaIdgmTysW7Ia8V0di8HBvjyDRKLkFndnLYVBd9lxBX+r4c8y6Lhga4rRQxifbpUyGtfS1Mp0qmdSXsfQ5VtgashVnUuxWK6KMQ1YiGyW1pKkU7ynmf6pzC7bh3v6HsgE8iD0u4zO8n4waDKjS7YZrHD3hkQ5EQoRqIlaDAw+SA+l0SGAowIRTNu6+O2F6q67jkuof5DfI9Fm/7rWiKom+Bk11Jld4AbUH3AdWRgzUlWSHaiioJEJlRtGS6SDLJk28P/UcXy6whOy3EZ/24x0L/T8pkyuUktXtDIMVOkv4naUi3t7+8OVHEftmFcBLKU4UwtASN/klTsgQBt+S0+fI+6D8i6fYbebYlP8LsAE6xbXC8ItzMpy8khL5fV9QPMFs4utLNm085md1dkR+S+NVUUgrbflIPFwtIReb9OllvDGsZw+Qc4+DrIuHu8Y3k6LeQ4SOKNBXKthWIkWn5gce5NjuRZAh0tY3G+KHWmoqrrF+7AxTzz8AQeJQG4xGf0/ahuKPvRc5JVlJ+jJkEW4PZ6ryhIOC3NSd492dZzcJX0zxiycHo3zwua+nHeC5wGc5JdQA7ldJ3xh7chzMRq7xSrLw4lxsrcB6+RoTKJG81dETxXrFTWCXntndzW/uzYey0m4ed2c0qWArD2NmPJapzM5b01I2U5iCoua2Enkq861s5kvH5UBuT+6xDXXGiCc7qE7Mj0oeU1/Tgd4lg5xErEtV1zyCjBbgx5+SZBTkKMkeiRrdYeCnBeIlG4Vc87xIm2eHGLW8pKxxeo5rpGAnsNjfkZZ4mVSIyd6wUm6vy5qE6QMUVJVcspbtNxWJQ0i0LRkeI/aL4/gy0n8r/MiBIhKKLs+V/ShQm5w87EWqz9OnFCyOtk9f4YR19n2QVCLHA2zHGXdWNAVzlXODHkda9QNFtIx/HNuJ3fXVEq7+di/jhvYtW3jeVlU6j7XVTSkrXEG5Fx5V8tL90vxDVxIdaZRxsrTReR+GtHhrgu0O6xsBiJno0Dnif+cAkMNntUjNhqBCXo2wJUc10Tt2b7ijiVIp0+YOdReH9FAEDyg06JU2Ab32o1HqiumMJgXywxbYKaT7Y4N63dwMQUebDlNVG40SzLh11DXn4at5tPHG3PMvE4NshALaNMJfuAyWlO0Dcg+40IFnKcuOw6XLyTHR67h1F6SsDuVkfLcw3Zx7PbitvfEEfy/1eW7RsOjwOeo3CeC4EU0FCMRI+N5j/mwVqPlpiy+rOt5U3PQhXXL8YPcucYH/EohV8ZDMOxBNcwALJEmIl2Gu40NkFXpQ86z+L8dcyOW0mTlhvN4RTOtUR8/p0O9mkG+Vfm9F39gSvxNgIS1uXkEQkK73g7E/eOC13LF/djg/hwgOVlT4oVjMOyFsvNqy0vK5Ab8Rulz/5dBt7VO0JcM2Cxw97pUbEPxUg8A4eg0cRF2zkrroyojrhE3S5E7G95yxepsiMNqF8kEGRjTPeWXQuOSHLVxZh4fx/VCkBmWOhOE+eEPmklggzy7jODUpfLZLvDTlRuNIeFvO5Mfr6fgTZ9JlV2bckT41n292clszxBl+CM3wt5+W8zUkxx9fnSsTzJLlu9La85PwOyFsWIbd+zgwP5HsvvbRbmeWEVkcv2dAIUI/FwccDzxKztnviy0aN1pq057r9QtXXP7jHe+zfcIb+XdIHMFmD3omoBcJ+Q7jQb88Rn8aTyaEyit7S4RCaRMh6wmUgmGi+Ay7ROkEHlItwewXNle94w1jFvc7o5I21aXH2uydFrKi5Cp2Ysz9uRvZuY8BLX36SMtDNx37/CsWzZLtCKi8ddGZC1WOg8bXnZ5g5k/dqMvK9h43Qu19MJUIzEw04WHw8xo4zJv7Rby1PZ2WBjyxv+E1Vb92wT031lYPiXFMt1OqoWgMxg604jH8M9EsyfxMMIGtxerF8Wrn5NsHjGRiPHTFkiwTLZWqi0WZanGmHjqVyVEWuRhZxP+Yk1Mo5l/3bG8hzW3S5rCi3Z7c+J98IokLezvOzv3Lay8p7cbXn+kiyT5VPMr3yLnsmCYLkNTOdDmG2a4UqTIkFN8iRad0scGfCU39NHwGZLskdDNkKQE7jDHi0dd0y3P5c7uuYUO9kXTBsHALiP7PxmG7sgyTgjNkqEuzpF/59gMTlWlKw7je2z7uNyRWG2HyamlbhjXp+lBm22Vb0/J+/nRRnMcxg3BlH+3ZSxdiaLUPc4kh1xzbPZHVX6xixZroeR82Zpflcd3ommK8IoXwf2OHfG+MqJTvboeLLQrWLEZpsreVGuNIMNUL9sGtN9RSFygwPluxxVDEAmBvcyIbnT8rJtRo6ZMjDuvPEzevFhR4tL7uxUrmlktzvNvknI2+wKs7blZTdH8FxZUQ6zS8i9RpZZIw/uNBIY8/ksZdjsWrVcyInkLLSz0NjuNPWIqztMVUG2cLbdCWjtFPP7WMbacRjFSI8xEqEYiQ8x/1wz4LkxuKh060YjplorWNxMAvHciCqtezaI6b63RrSyWCvjyX4VGgCQDrYTbxkQ7ZxAvrbn1DfguRKA/T+L/M1G4ZPUFo9h3GjujOC5W1K43WgmZLRN35GDb9D1Gcxz2NgO92S0jiZSylv3cr8l7/VWlpc9kCUhm40EXrS8bLUUs5w197cwSrI+PZ0AxUh8yMqUzda9D0X5cNXhRlN1PHFQiAkjABvGdF8nAuTxR6w1osE8ACB+7iM33WlslAgPdrFri833VrZ43NOxMnXUTUTK7o1DXpfJCav5BmU5EHgbZSTgbUTtbGJG25m476fttrU6p2GW1zyQQXG/FEIuafFm1ppyHDeFYiRebKItPxHlg1X3bsoHZnHiClJn1ZgGUg85VMbbUM0AZGYSaavI3HnkmClNceWJ7y1jKpsgr+O7KNerfHjX4h77xCnnEDvsRDlm+E6Ia15jGX6Q4aY9IcN5f5hl/0UG8x2mnX3MZZ2CdhaaLSzPF2XO8xmUs60VxjJxfqN6atMZk20sbmxQjMTL1hbnyrZOEQa9qWotshynVSxv9iCqsr4xW13G4Z//OA8u5rs0sCNHIrYDACKfgMtubNvGmB+JwzQ84Lm6m8mJjcJnB+6f+8VYpt0sx4pRudEI64S45qmMt+mJGc77fRkc24jVVZhFn8kZb2dpj+ttFSP/Na4pWcNWMSKTt8VTyKc2lkRZIp6NSzCuihUJwraMxccwMjMmVX1udwwFCD7TibNQjYBZKab7Pu1SIfnDMJvsfUIBAOlNxFxyp7FxOZnM/U21nd5s3Gnke76bI2USHorCjYYnrItRgK0Vu+C5LDdoE8zzjYxmP4u76shue2FW6CdnvJ1N5UOaAYrXsjz/hYyK+v0Q1yyWQj6zGNtobhw3hWIkfmxMv+6K7rG62gDKJsK7rPzciyoEzLIOvB9J8TSqG4BMDO7DuNPsYVxe0lYidKf8kN0BvojpuYFhOfUmux12hFsienxY183JOWjaWbR6kUWF/2Uw3yuGvC4PCyhPpPFQ7lca+LCy5WVvZlTGYdxTlsDXPRCxbC0MxUj8DLAYWEyKOS+iFV/XZtxJdr7OIL8sHdN9XVSMwGIEgOxgGxdoJKdNYhjsr8GHURaXVFWMTB87WgZ8Ni4Vu5ltgqPmuxQgin8nxNT99oievXzI617PQZvOomJEXB10BvO9Qsjr3spBO0vLukqUIkXLazKpGDFWyM2Wlw0hkBpQjMSPWGlsQ8G2nIskkrpSurvOaKjFrWZw+hRVCCgexUg7pw8dLCsUIwBkB9nu1jZOURwWFjb3nMID5td6OMfGnUa2B/5uDGWy3fFGdtn5PKJnLxfimo/4+c05aNMvZzDP/82orMNYw8rY5YMctLO0XLbWCHHNexmWs21A4n4EUgOKkWQQxUhQ7WjNMT26iS9iu7/8r1B1wDA0hnt+wINYFwOdvo3qBiAbmImwrRtqHHFGonKjWYi4sbZZ3HPfKAtjglLubnnZuAizEMacfEpOmnUWV8dfy6iswwS6fN9YdWWdtBQjy4W4ZlqG5Tzb8vwigdSAYiQZNuRUCHjuP6mija6BLo1TtiY7n92pVFmJA0AYEcM9pzo60ZKATrNQ5QBkBtsJ+Sjj+hKVEmEpPqxvcUmPihHuhyQY3iSLe+5hfPejwmaHHSFKN5qwE9apeWjMxvx+esaynVULiuEhrvmY8sE7FFOchh6wVXq2RhHQOUVsLRphMZIiUIwkg2gqbg14rvjH1hiEtUtXmp9a3uRgVBvoxOAY7jnD4fIitg4A2WEipetOY+NyMpPTkwHPtXGnkT56y5TKJETpRiMMy9k3xZasuQ58klE5h1n0+SwPDYzf1/aUymK760pLxkW9AJ/o7ABzneTYxeLcB6gGU1/V9YBpOYtbyGr5+6gy0IkBMdzzC4fLOwNVDkBmBvjNI8dMkQWFAy0uk2/s2RFlwUbJcpeFGf4ETpdb3Hs/Tg+mUCZhXMTVGkYZnydLv6y5DmQ1Ht3AENfMzFk7S3p72KUsz9fcv++VYRnbKnnbCKQGFCPJsl3AQcuVloOhnpAo/DaRt99wfNIKkicO077ZDpcXihEAsoVMzG0UI+vxYHuZ6WNH1+QCwPcYRBVX1aAEtgLhvH3I95dg0EF3k9uTzz+u1thNIXbY8cnOuiWub85nOWrPmXKl4TaX1W9m/xDXzEI7q3lOYoP0sbdT/QALkxSBK02ybBPwPPHVfTX8Y77lSiPmtb0tbiBbxTWjukAnesdwT5eVbzNR5QBkijDuNHtG8NxdKfgik5iE32d5/zstzpW4HBtHUCbb1dlJPDGOus/sm7Nvii1ZUvL4GZZzmHZWylE7S+Od6UWgXvqxzAHFSLJsRJXte4OwdYTP/bPl+eegqsAi9Inhni4PLqCxByBDmN1pbAOGR7E7jY0S4T7Op23fYmuJsW/CZRLGxVClA+q8Sc/LUF7nZljOTSGumZ2jdtaawjP7EugOhDJIEShGkmV7TqMDnisrS1FEvl6dgitjhMk56/QBqLeBHgD1yi2W5285csyUIWEfxtfKpGpni0us3U2mjx0trjQfWlxSk7InxA47Yi1wmyP1PwcTVgCcb2eNEHu3TIEI0gOKkeT5Z8DzJPiO9V72nvpWTLe9YsofAHmmDBEAkDkkAKvNDgYFTrvX8DxZ7Ai6+qkp/I5zEyzOXX7kmCnr1lAmW/eiSQ7Fl/Bz1JahGAFJkIbbfG+IvSrvc3/6EcSQHlCMJM9aAeUuipFn7G6t+L9vjQtsB323oIoAAABkDR5QivvBRMvLatntwObap2pQINhamuyTUJmEcWh5sQDlfDLoOi8/NuFwiwchgnSBYiQdDgh43iVktWog/fs3Nutdj9NqFvmSbYKnoXpAF8Sxjzz8TAEAUWM7Ud9x5Jgp1iuYfI2Mn/awuKSWXVsmkZ2bSCjFSIgdduJ0owmzkp2nuCR98ConQhj3qzy5gvRL4ZntaHZVuRIiSBcoRtIh6KBForzfH/SmSn3LWuRoCr4VmQTCvILyFW0bREccZr0NECsAIGJs3WlEKbJjiOdswmmExfl3hC3Q9LGjxYL0XotLVhs5ZsoqIR61C9mtIMfpRtNW5xNW4O4kHUqr2kBw+675K/enz0AM6QLFSDqsQ8FXywO7wqhvWwQea5EnCbh6K6oGVCEOP9T+Dpe3gCoHIHsk6E5jE4vjDc7XWzUWbXwCZbK95vYYqzJMAOx+OWrKg/A2J8L8ENfkKUbGkBSeifg530QU+b/hdAJEkT7wLUuHFTkdRcG30X2d06oxDtoE+AmDpD9kQxwu70BUOQCZRb5nNu4ke4wcM6Uwfexom7gONkqEOyMokyh7JH9Blbb7cTo/6M1D7LAjKzFx7kYTJsbGiBy1YShGkpuU1nM7G57CM20X2kR5lbf4h2I1M9PM7+7hbw92A3UEKEbSQ0xWgypGnqMAihH1zV9tt+y7DVUCeujEo2akw+WFYgSA7HI3VVwxgrpWDOa0JaeHAyoRJHbXihb5GV9rgXjg/AU/9zEKHgNkfT5/Gb7ug4Dnb0d2FhdP8L0/ibEOp3Nato4nrCPwGieC7ACysuU1i+Wo/ENTeOYMy3d7Nvc1R6CpgiSAK0167GRx7gMh7r+f5fkPoEpAD4OHqBnmcHmH5bguezmUF4VXC0Q+ox47Wtww7rO8zGYxwcZaRCb4T0dUtDh3p7G1Mr055moMo3RZMkfNeBje5EQI087ypLRaPI0u2vL8fmimICmgGEmXTQKeJ7E/PrC47yFk5wP5a1QF6IE4ditaxuHyLpHjumxyKC+wzAFxYTtx3yumcydMHzvaj6hMtoqRfYOcFGKHHU3xxySrd8XIMniFE+HjENcsn4eC83svbjRpKB1s320E6geJAcVIugT1Oxb/upe7O6ESeFUvrNMdLOpWYkfAWgTEMUjt8bvMH2ZXA7DmelDKckdUfVAP31ebnU2W5vdivQDvjky+N7S47/ioCjR97Oj3+PCqxSWbcn6DrG5vRHbuAXG70QhhrBRXzUPDlXg3fFgBr3AihGlngwO+V66zUkrPtV1o68PyhtUISAQoRtJFTNqXC3huD4GHVOd7rm/ZQb2LqgA9ENcgeLSDg1JZnVg65/XpyraW8KMHscAT9y8pHncaG5cTic30YMRFs1G0eAHLZLsbzc0JVGGYCeswswqedUQxj1XyZJga8ro8KOHSGn+9H+KaJdFUQRJAMZL+5CRo0KebuvtHRV9Z6oqZ/OoWeZAgSNNRFaAHPo7pvms5WNaV62BQ6ooLCxQjIE7icKexUSLcN33s6Ki3Orfd4SZqZU8SbjTCmyGvWz0H7XY1vLqJ8Xodt7N1UnruayGuWQlNFSQBFCPpIoqR9QKe287puGr/qNRXipFjLfNwKqoBBOCtmO67kYNlXaMO6tOVqPpYBQJxYutOs8bIMVNGVftH/jdRKG5jcb87YijTs2Rnir6dyXe1Mq1CdrtyPJ2AG43wRsjrNs5Bu90Ar25iTKVwu+5tloOyfyel54ZRjKyNpgqSAIqR9PklBQ+G+B9OXex1LW40euEvZ1s8Wz4Gj6AKQABk9c6P4b7fcbCsG9dBfS6edgZ4QjaI8rXtIXCMGNxpduVUDHgf6S/viqFMct8JFpdIfrsLrGrrRnNrQnU3hw/vhLh0c0xYgeX79HyIS7fIcrn5+yv9wropyVze7Q8tL1sPrRUkARQj6dOXgm+tK7FAHl70j5XAqx0xRs62fPZtED8I+CGTVdc3Yrj1uvyBHupYcbeugyp1IbDfmnizMsGgjOff9ju3V0RKhMe535wVU5midKex3aZ3XIJ191yYCasJXprVCauMyzcikCTPhrhGgjUvm+EySxvrneLz/2d5/lbm3QAgVtDI3OAGi7pYJPCaIqU6rEUaQ0zo/g3RAwuej+Ge0u53cWhQKoH7XIt7EoelzooOlGtDvFIgAeSbWbI4X3ZyGdlF3yCWnTtZPjcuJKCrjfn/zl3tRMV/W9xyEv7M9LGjP0iw7p4Occ0AyrbFhayMD8VrmyiPhbxujwyXeceUn/+k5flDKCULF1BfdDcZVxBPogT1W36m2pyO7PZWnx7TRBfk90V6Jqb77ulQGfdwsMrmxHBPFwYYOxHIAoUsZ54n8p+T3c4wqsqEZ1tONtuLj4+xTBLQ9X6LS2S3up0j6O/GJVx9k0Jet1+Gm+wuBJLmUerkj27BAWhnoQnjxr87miqIm+qKEU+XIZ5E2TXgedXcGWSlewmL513L6dM6lbVO8mFlVdI5kdvjMd13j5FjpriyO8n+Dsq9OYZ7rs0yT23LXn62rOpuiW4/E+Rh9dp2Qr9XwL9V49XpY0e/E3OZbBUv+9RYpjByrJWXOYVxR9qf+5isrknshi4nWYzydHKISzfryrrMdTjPsoi6fsrZEPelVstrDkZrBXFTVTGitZoH8STKJlSJNxKEHTrP8M1WvadZPu+sOpZ1ogOm0kf9SzmR2yucPo/hvrI17pGODBZ2cFDuX8RwT1lBTlMxIQOcJgJZYEgOynA72bnTbM/9Qf9OfYOMlWzM5scnUCYJ7GrjZrebcQdaWCZRTm5rcX3SbjQLA2NODHHp0pTBWFFcJ7IlKVwM0+HukGPJH2WwrIelnQF+t1vI3gp5RX5HEJgYxEp1xUgRipGEkZ0wggZyeraLAZGNSd9TnOanWlqdamqgBOPrNA1ub81DAzWD1Ptiuv2P+YPXL+UiHkNuej5Njem+qbgwmZXcY9DlQzGSYN9l604j1lSdXU8kDofNDkrjEyjTZ2QXg2NRRchOppxBGZdS9YXd2eekDDbVI9DdpEbYzQh+lKb1ZYjvr4x9D3MkO/eGuOYENFUQJ1Unh4U29SXE4+xHUSba/yVauCONtvW7uzHdYnKeVapJVs0S85v3BrYvyFEbvTum+8qk4ycpDhaGOTxZfy+m+x7aVUDGBBCFzFoEssKSOSmH7cS+804uNi4n4qL6bEJlslXA7BuyTLVMHGtFFCNhFnL2MFaAWZmwNhIUI6kxfezoV8l+p5SFY5fvZaio8v1dwZG83BnimgP5XVkKLRYkrhj57PZlv/R6I8xIwmwd8DyJOfDk14qRbwx2XB7gVNQiOvUk208mZsavSzQjR210Aqe2mO79C/7grZJSuc7g1M9RmcelGJH34OiEB//iwnM+uvpMMZrrrZiDcti60+zSaSXYRolwJ0+ykoorZasYEWVBgZNYTe5qcd0LXKb30qg0fu4C892xRSzTfp2h9nk4p8XR3aTK2JDXndnZTc1xfu5KRvjdFkXUm5aXSd91KpoqSFwx0nfj6aTbsJtvwtj4lv7n62+/lS+t+OumOlEveh41pJj4+RKoNsH929VHeWmg/CETS7K43GmkTm5K2iyVn7cBH45zWOwvxXjvM7j8gxMsy7mcVkZXnynkfVwvpndvBKe1kwi+bNxpbHZC6HA94bytyseVYlRW1FImmVS8bXGJfPu2oMoueAMsrhuXchu8KqyygevPees0UVZhsucE15Gd8nQh4gZ/QgbamexE41qMjjAW7MdwWVZEcwWJKkb6rDiPdElpiChxrg94XkfgNUW++EEvE/AaiREh1iKpmQKJGqeovFSTR2oEJRhjhJmWw8FDXKxrlCOJuDrxc/qad87ZLUl58jOTD2/FdHuZKP0tIVkfRSm6S4Ga2D3CdtCP0084STBn2TZeFH/T+fcXOMUdEPgWy/P3IjtrEYnN9lDCdRPGncY2vlDaipGHOb0bcshxaQZ2qPkhJ0z00v/WTg/RRyzk19zOlnNYKSIK7ksdHU/6lteI1chFWW9vUicZ3j2r/hQjekGBlKLZEFHibGkmK0H4k1L+GRQ8YKTEJnkhtZJpbnB9SlTq10ztaaZCabEki11sKr6XszYqZs2zYry/DNyvNubecX6UimYQtGoGZP5kjPeWrS3Pj1nW3+fD39G9x05LTPf9Ptdh7xrbwFBOshua7GxyCac1FjlFlKIP8Dmbxyif2ywH4bITzT4W5/+HJ1dJB9u29dPf01Ix8kICWw/3NGGVOvtTyMsl4KyzO4fIe8GHs9F1OcMfQl4nu1hdZ4KbuogsSqzkWqbMTldhdp4St8DvZa1xSVw3TmKpK9Z+EhahhX+eAAsYdyh2M4cVJIjYYIgpUcQkTwaGtwcZhHH6seWg+cW0CqYKmua/OphKnzdVgqCmAT+290pzVigMaP+qkcdcavpy2ox3gm845D4y8OdOXEybT4vxMR3+1vycg/l5kSthzOrJDVTZmSELPErxBuY7jWUiCtnjWd7NEcpZ4rZcSNnc0hCKka8RZbKs0B0Xsg3Id+qnnAb2cLooQ2VVM5YtS7ltz+D8TKLg29QuTnZxH8anUOeiNJU+cmjA85e2vP84R9r2NZx+F6ANdcXFXO8Pcv2/5eA7ezHG2U6Nb57htiIud1uFuFwWNn/B6RzHJuNrmHfHVf7IabcQ113OZXuU6+yTjChFJGisKIHW7PTnRlP2jfnf1+WyfIS3MF2qajbbdce8cQZElApBt9613eoq3RVbRVSeXaS26U3UPiO95Ld5iWkplKLW5ta2PLbRyyl+l6wdOL3CH4vdorwp309iXDzGaf8MyVusdPyYnyGuLv9l+ewZgYx7cxJlyOtQiiRKnFaex3KdXh7UcsS4zIgyRKwNzrKY0G7A142OsRxxTfQlNsHdSVc4D6SlH74rg/KyLedcCr+aL232Nm5X/R2bKB1IlUUA4Ba/qeFaCcS6l0NtrL95h50NDsvv9gMUbtFWtpK/OQvbJXMeZXFh0iJKkc7Izoh/w6uXPlUtRoq6Yx77GcH7KQ3EPOygGO57WpqF0iVF/TaZSf2LfqrC1c3FlXU5mYattX535JL521mMP2Qfckd/QwKDOlmtnWBWcM7k9HDYHR+MybKsXJ/q8iChirxncv7v5x93jPlRYs55hzHzlBVaCbT7sjFl70m+EutIVsxEoSUDw/4EkuaDmO9/rHyfuK7FBe1xqsS++dIkbQZ3a5t2Kgq2ASGfsz6nKTGVQdxpRLEbtcn7Y/yefJFSvY+PqS9O3Y1mEcSa6DjTzmxZndMt3HZ35zKlvlrB+ViHD1ejy3Lye/sI148oG8Msyki/InHSduP7PJRyG2s0SpHudvsTxaoLMdZ+S+Es7jbjdCU5vNU114MsCoiF/6geTpWd0NbjdvMC3kIHFSMNqsCjHP1+mXxIKR32o/BBoLriZ2kXSHuaytIFl9N1wSyUvKUTc+VR6rWyn9ttr8Uv+tCEPqpi1vqgTJb4wyFRzGWFYXJPA1wTXHV7qgSPPJgS3Y0ocq5OQDGyELGqucCkuSxHmRxJ8MO5Jmkz6ZUtf5egiu/yQAJpMzWBZ8gq3Q9Miovhcd04hDuNjXIiLURpKrFNolb43u5S45Zd0bjuxCXgzyFvsYNRjuyXpnLEWESJdVHfKqeIolEskIYSSItTzfc2TKwzGWfcZdrZxJTaWKOZQ3Q3ZniaKotPyzrwbt/JeRa3wE1DXC67T03je/zctUZkXJTFun/tgJfIrmFQjLioGPmicR41+IUpvcqNkFI6/DVCxYj4nT+WeokUz6BTVopoWclOSCmi+TFNTfrNxl75bKD8ERIlhZj+HZvgY2VA+RuT2vn575oJu7j9SWwM0eT2MxOrVcwHPy/7jssk5f0UBjFi+bGOScBt3slJOYbEfP9xeVKMcF88T2Jo8I+7RHzrWxxsG1dw+r7FRGNRREl+P8trb7OFc9ITpdWoYom3RDenieJnDBQjqY5v3uC6+j3/+MuQtxDliFi7ioLl0rCWriHbmCxY3Mzpuz2cKuOoKx0SuwSIfZoolK/CaUYZdEqSsu6hHmSB6S4zbg1KP7x96VJ1wlDyylRW/oeU4taudU4f6t78zaqPp3Bb3UVKsV1RIcUkz1dldXlS5VUSU6VNv94yL9e7Xot7S1q7V8lKjnx4ZMtqMSP/kVHSHGb+tnyOlCIyUJMVxIvRNYJu2ogozvKwPfiCmO9/B0UbflvczaamLLM7I77f/2Ry6Gg/KNZKtZgzi8ufbA+9ScITpV358ASnJbs5Tb6nlxJwAbGKfb3GOZZ8s+8ygTeTaGMb8OG5AEqR+/hdus+xd3syH66qUbEy3iiG0laKiNX/ZEuliPAKXjtHFSPDmgdQ/7beEgwHAVjTnfRFwUdp16OSMWihnGoqF/QmnJERSZZbKzW57Oc3UA9/yETpdjpe18T4B0nsp/zwDKo0ch7LQRnmxdxvTTMT1Ki4wwGZTYj4fjc7/N2RCccFNd5GLO8e5wnMpSYGQJyTpL6cZLthWT3uadL2uzQsWUCX7UysrcVduL3GW4kl1+vcBn5pdumKo41JsGt5J8TioqdYFuJ2d5KjYhcLm1p2mRGLsMksi/VTUoiM5HQTVawSbWNsyXfvIbx5jipG2hrbqb2x9KlWGoqR9BQjq0V0r5OdKJFKPUlQ22KCahFSSn/geTrvbVXcaSblqDwyCJrr6EBNPpy/zYmcx5lBHIiWB3NQhqkJPCPKiX/qLidmy8pnI34/XUbcACZHMAaWgNzv8GTm5yZAd5STpCKnI/hHsbw5IcAlr1IlMDBw55v7QkRjaFGIiAXKVG4TF3FaNaI2NoTTz0yfKccgMd/OctEazMhb4uscTrVZ9K1olCOXmDhzSShERDEli4QSkDzs5hnXmzEecFEx0tS/RE0DSlTsXX6eNASVEudyqjVCxZwIBg9RqAiorItppiat1boJv153lstee7ns5bqRmh1LZPA3OydFkt1YXF6xE5/gFzMuYwl8+HMCcSCxLrLuAvtaAs+4laJxp3mN+0BXzJ+jcqf5n6sTp07fHVFgi7l6FBZ0ohA5j9MnPLn5t+woUsvKPl+7vJkkyc5KYuUXxI1CvqNHm3IBt9raZXy4NqLbSVs7RfoNbiPPcTqf03eDWi3xeYrTKE4ScFT6MFGIXkDB49E8yul8x+X9gHkfa53fimvNWyynHwXdZj7Eu76aKLr4Rwk9cQ6F34lN5mq/w9uWPlVXz2dP5H7cV1Qc2fx075XnHJXU9qbgW5zI6fc1Dv5S1op4ssNRunlQ1Esp2jDJbKiG4hOqUKyLGD0S20A+1JTuzgxR0G4GDTs5LOsSy/poqrihNGRUzmdyOd7lcqCHj759TGO5imvHvhktwlQuwwcJyEkmweJOs3mNt/qXQ7ITxchZEdzn5oy0ddk2fm+qWElFsSOPBG88wKQy31v6WFlYesskcR2dZyYxMpoYaCZCIzmtwWlNThtzCmMNcB6XB66F7vJDTktz2i7Ce65v0mlmkj2jm3YmSQL2yrbTYa0gxIXwQG5nWRiX/prTehGMxURmspnF2SzfG8hYqoaVAd9D3PG/Y74bu5n6iIKfyI5peM0cVoy0L2gg7StSbW3oqNPlghoVI6kOcFSDT9S/ldJUq+mSIj2710Hk6ST3h2mnUulNXaqf2MVmuzX5mJ2Z4WL8SYIouj5h5zy+KP7KNfYNafE81R4fAHTPORlWjCS5RezNEShGxjnUL7zM/cJU/nG5vJQpQJmf4DIfbPIcpXmmuCRsSuG2D7VFFHS/RbfldDtr43Ymfep9ZmIcByNMigMJaL2ria+UBXmLYlLc3ydRNDviiUXNSSZ9aZSeL1PFqusLqiihWsy5oniSRafBVNnOeBmqxCRaJYK+tSv+xuW9Bm+ZG1RVjAzf/8PKpLLde7k8RxHBYCRN5MP8ZIjrpBJT3Q+7bUYvmv/UMErNYISfWxzSRv1XnPdXnWwe2osLvCnKr7sXR3xoJfDX4Vkc+5j8Z4WLzABtvwzlWYK+HW52lgDxDSpFcSYTxf0zlnXRJP8lweeJReUfKfwI5xUHXU7EauTEGq5/3XU3mi7a+23c3mU3suspezuRyU5S+6JPzEQ7kwn1DvzjvZw2ylDWxRJ2bxMvJWvylh0GH6eeA8raINY3O5iUNhKo9Ti8Xe5Q9QNS/rzYkfy5coq6EaJKlTEhr5OAcKmaZvkLGoi+7EU0J72k5jXtplXimpm2tv70ausATZLqaOAghT3adPZZ4zjOf5xxUlpikLUooJ7KmIxfRZeeCOLH/mXG8vwPbh+JmWuZgKW17E5znYMyrDXOyK1ZbOxclzJOFSVxW4ayPZMqq/jT0V1lZ7LOh2053ZORLMu4Yz/Xtua1kLdYuGzN6c0cNidR5B6WEdemuqGqxUhj6et/0p6+uE2VDoG4UkNMfWWLN9tJ20/Tznif5edR/9VTjMnJU8dySR1Unl9M9LFtxcKLXyy/LD+8/vo7YwIpq3ftlB3Lkes4350nBPNjeMa0GGS9wKyoxGneGxV/5Pxeje48sfdQ4i+I2fC1GcmyWDieksJz/03h3GnE+slFxYgEV5RdtfqHvP7GDLf527nNb0MVd6wRjmdXTPd3jVhRDKuTZNqZfHdlW9gLqRLg01VEibM757e7LdzDDFKbE5b3RyzvzagSw26znDQjcYU+zyxwAYeoajHSUmz7KrV67a9r0thWMT0kqNfSlteI6Zmfdsb9Fp4df15ML31RXLc8v5ioObn0coMXtOy/zJSptMy7H3SkelSO8OFIyoZriviZLmrKGMeuGM/EJGsZ/GzP6QGHZXxTlQGk72Be48hTKaX3UCbuf8vAOyiBBvfk/M5J4dkSPDWMlcE4zu9MB/teUUhPCHn5Q1lzo+mi/OJ2LAEtn3A4m2KptCXndXIPk1pb0tpNbUE9jnE4yTa+Mr78wsEsioXFxj0oRTqKEqb4Kch7lhnnZD0Wh7z7O3N5znVMKZLFd7g1UcWIr3TnxNNb9SSBNDnG8vx0V2a1pkK5TMr300kmoIj2lKykJ7tzh1ITC4pm9Wpppl6tLR2pHpFOn9MZVDFvdtWk/yOqrNotaiHySMTPEe3Y5BhlLSvEYjlymYMylkjwh1UZBEyN4Xm1aiI/jiFPH6Yof1H6uezaJsoQWdVMZQtqo9z4Z4hLr3RYpn8NeV0ugiLLCjNVzO9/Re651jxrJqz/7eG8l0Pc+38RvpM2zKQ6hetRXNZlN6K7HMqWBJX+TkAlp+3cTpT8z6ck6xZO4qoti27zMthcxBpvLS7DfxJ41md18A6HUQTPCq0Y8XTxG0mR9xB0E6myjcW5bZTibjQdigk++oUC6WJKqcBN21N7cjaGJS6AxsbLPh80iGYNGfJVqmeMi8q6VIku7hIyKd/GDKIXRVaR50b4rIvi9iOV4H2cTuAf9wjxUYyLs6l7H1qJhxClXB7kZ9W6ajoxYhm8JttZp/j+iXzFte0iB7sHGbhvxnmc5EA7tbHqeTnASmyafa5YjNqO2R7IahyCbvrDc8y350EHsiSK4T9w2lzc3AKcf5vl/V+IcJvrF2I+P29jnI85iWuNjDnfTjMrVNmO90AL67t/kN32CHeYhZg05X2tKBjIbSvZzkw237lDjeVLEjxSB++wxCOzVeL2uACjdJWtOoYf/q34Z15Be+X0thcBzN7SKXXxse2MmIHLfutXpZXJcrFIs5ZeqkNBkRa95s6jgZ9Of4ZUsnEXFNGsvuXy5qoy4P+Kt29cKdMNT6nad9cZOWaK3EQ0/edR+v7fskoiAck+7Sa/R5hBQ63IyuAGSe46wHkX+V7M6dCU5CuBhY6W3SIC5PVSPvw4gmeK3/MmAVZie8pPLzNIWDUiWezGebrbhfeYy7YrVVxrlkw5K2JGJ7vB/FZWAR2RzW/58JuAp++c0KpfLeWR9isru70DnC4Wc+skGfg2BXnsQpVtrNdJ4fEyGJfA009Z5FcCoz3Hae2Al+zF9x8fkaw2oIplS1C+y89+gMDCehNF9Gmckhr4ifWEKN0u4HqYFyLP0hcH2clKvrFrudRPcN4PMmPKZR1sDuI+fT6n8Um7zbBcZFH4HU4D8vwOczmvMHPeIIg8Vpl2/ahSKMXIiMPf+tbfPO2N5UsOJZAWMonbwlRuNcXITNNBpOMvJi40hQLNHzqsw3IkjeeXmpqoMH/+D3rNmf23pPeZVqRf7d1eWtfTur3z36f8a9VMN7woFCOdOjIJCniKmQwPTLgo4pN4LlWCXrUHyKsEyKolToq4EG3Kz3otjXozA1yxFNgqwceKMuSkKpY4XeVRXN3EQmefGgeGoui6NyK5jebDw5yWqvFWP+M8XejYQEIGSqdTxcWmX8KPl5VGUTZeFHDVPEm5iCZfdgk4uIdTz+e8/yIjg0aZNIgrW3db2Labd+dOyjlGOb+9+fbsRPFv7SuKqd9TJR6NDpFfcdGQld/BPZz6Z77/iRHLShTrJwc49Rrj3gC+KT9pW+LeKrIRhXRjDI+ROCKyCPp3E2ssbF4lb5dz+n43p4kV6piovrERy7qJKuEGpL0unXJ2pD+VvvRPLKtHU5aL9HGymN6U13fYKIBEibtcgHrZYdr1oyb1ON+pphhZ+sRvW9XwmUPKcwfO0thYKE2mclq+imJEVhf2pdp97MNNnrktlT2PmoePoMb29lSEo/n5/Wd+RmWtp5Q8b1Tizyf6ZcnrmHh/g1nXjsp0o4tSMbLIBO0I80FbJeYitJkJwu9szY05n+KachmFC4AsVhNvOfDx2MhMBiRQXFymXFLeM8K4RZgJiwzsf0f2yjIJNPkTfu47EctsJB9kNWKvEJdLnJJjOE8TXH2nuXyy05lYcMl28OvG+CixRhC3jnHkgBl2gHYoq0+iEF1UKTbdtO+/Z2zguJWZnHdlPSmWDMebgKX1NnEVq6nvmfd70wiVJPLuy644Y3sIrho0n7LQJZZM4qoxbJFvmihN/sLPuSOmd+FHVFGidqUgnm7a1R/4+T6B7mQp3zSxWNqR05aLjOFtkIUd2QhjkulLX4o4nysbZY5s+DDEtLEZVAlkfHcYa5SE5SwKnv2MgmebhB8v86+bzHs/0yGZyLf9EqrEXMrlO8xlHE6VBUBZCGioMjY9edr1owJZwVVVjPRZ/ttuO8rTffquPXuy16+0Orq6VJGoxuJW87wiXdKk5pkPsWzNmFp0bM2T59lLLEFt/Xult9cEvxLDX337px55ya7S8mvkNXGhm3ylunilPv7LylCMdN+xbciHA6iyshKleY1oeCXezj+4459R4wf3YKNYkEH0oC5OE22gBL+T2APjjJ+/ax8QcbHZx5Rj6wgmAzLpFQuRv9qYiXeTv6FUWWETWYsPcbWGJx90mQxcE8XkI0DbPMJMoJbo5lRxCZEVIgnk+W/OV3NW3m8u43JmwC7b1q5u3sHBIW4lA0LxsX+dkwzaZSDyXJJuZBHJo2CURStQRZH4nnxvg1iZOVymJcw7JZNrUU69mmfXmRAT182N8khcbVYyk9emAO1dFN+ycj/Z9P2vxWE2bywQFuc01NTfR0m0R/PcVYxM5LsnlgnvmPaDZdJwMhWlg7hIyYrZcuadlL8ttCqR/lLG9RIvaxpVFkRlW+c3s9aXpijjpcw8SRRSYmnfN4Z5mCipJCbZxO7csh2Rx5Kmb1vYf+TuHeYyigWsWEmPMAoSeX9emnb9KKu6qaoYKS7X0pViRA1Yd+YVDX3bfoDXLnWkgkqavEM8Kr+sSU1NeeosvlakivxTOU3Fo1rCL6v3KB6zxepP5bK3ftL3X/NfHXSQKnz7nWr5oA8UI3YDePmQrW8G8uLWsAz1vLuQdH5TzIRMBqkPS1C0mPIoH5eRpp21mw54epa07uYjsrFR9KxvJoHL9zCAmGkmveI7K6uVD8QVI8K4XK1hPnIDjRJGYpe8EVe9BlQsrWIGsWLxJMoPWUX40Axa8zTIGGAUQSONkqTvIu9gixlgiTJelI6fcPnrbttOkHuFyVD6pp/+AtMXzciyogyAOnqPJe7LmkYxsKYZ5yxrxhbyfvda5JI2821fYBQgMt4Q12AJoi67Rb3I7/50SDYbVNNzWCtGFjv5zS7uzv+bW1y50Kpe8ZVugLjTp6QbVEGVSZHsBJNOYFzfV1TwfCp67SkrRchr140X+V7hx5R0cBFPU8uMXjvMf23A/V0pRtreGZjpdpakYqSbj9sQMyHtHBdhoVJiFn+o2tAjRDYZkImwBG2UFdOymQDPwMQXAAAAADkb98hYp8F1dyFgT2SKkeFHdO0Wr5Vsx6rOK2jv5xB3+pR1UWlSHUoRT6WjlCgWNely2TQO3ZEXaVc6Id1Ep0n7Kb72UtmSUmn1rOpd2tbrV5rXlX7qo0tXQ2MFAAAAAAAAAAepqhgp/F/1rX59nocu3jyozVc+rEZSRhQjC3/WlM6qfv/+JWpewO2iXCDl+V+Fg03SgoWftCIf3krDakYUM55SW3haVY0p8eF1y6GxAgAAAAAAAICDFKv9w4CW7uPU+ORLQMNDIEJ3SFopIDo15VV8VhRVLEXkj2VqIk83Up/ifIrfo0VTm6+bytq/JC25++XyS2W//LhGEwQAAAAAAACAzFFVMdKnhziHWukbfdIHdncPkG88UYqoMn3b6Eh9Zb0iW7TY+nfZIc/Rst3rbqnIQCma37zgorlfftlDHI5V0GAAAAAAAAAAwEGqKjV6DK2v1T2ktGzPuAXEWIdoor79SrRAjEK6sApp02VqLvvUWGintnJrxxk+X1PwypWNyGrB88hXonyR5tu0DN/74rTE4Gv9SXFA07iB/YahTQAAAAAAAABABqmqGFEUYNdBrf6oFRQjdYnszlvooXl0OkoSt5uS31jzRrrK98mYqazK6QlOXkpS8MuFwq/Ja2grFNAkAAAAAAAAACCLFHue1nY7872VlGqlypaOoE5QurIBTU9NpGJH4vF5fYkKigYMLNHbU1YitbGmIHq3avT7bBb1nv8leT5dqSvbiqbFgl7Ku7ejpAgwAgAAAAAAAACZpLrFSKAV8I6Am9/1fe9h/gVr5nWBonJBU4MuWV0jSXmqo5XoJlVxpxFlQu+Aly+grzx2tNiHiLUS0eapaSRUx97Y/y63tnyENgEAAAAAAAAA2aV6jJFyYD3HY0rRdTxNPArizD+eVtRe8Kmx3eaqivKiIwgrX+c1lysWI4rI/7IQ6HLVt0TKNwFdNe2jtD4uVTmowstln75f8mAqAgAAAAAAAABZpqpixLdxdVB0WcHTR5FSkGjO0V47edoLea3qcIPp9/6XpEs+6QFEM64aRVTqod1wW+x/0qvUZ05/0mW9Cze4ayhdC6V23ayPK5Ql3x4aBQAAAAAAAABkmKqKkUJ/KyXHiwVFD5abaTvEWsgviv+b0zSX+pQGhr+H75Mqi8WIT55vYo2Ug1xXIq9cXtMv091aFHApKuH8cvndz2d8+GK5ZONOtCwaEAAAAAAAAAA4SPXgq/P7Wt2oTP6+Ws//VBUCRY0AWUSirqraNF+i1NCe1xEnRFvpNgrL+Lpwi07bdYXzr1Th2D6Dhsz3ZXccAAAAAAAAAACZpqpiZPqNI+zmiwU9b8hOH99RHNJ6EMSaTxT5ttqMntFEXt9SJY7I13/q9Ewiv6VIjW1N4zTplVJ/YQreIx7RQ32GDIXnGAAAAAAAAADkgKqKkf4rf2x3J0+XCzT31GI77V5qbOpHGj41ecLT/teaiyjxFY085F3y5xfFX6bjT6J70b5HytNioDKC/+Fab36v7/gqZQsNpeiLzz47XVu50CxkSTQiAAAAAAAAAHCQ6rvSHNxkdydN9OW8/h+TalhvyMcfv+UXEJQyL3SE9PB1x+bMsdy/qUyq3ftKMVIxE6EOxQj/7yZuWtv5bem2J9WgqaFRn1L6vPnJkm5HowAAAAAAAACAnFBVMbLAG2Z/t0pMzrfVx/5YIm8MxJsPlERHjdFvRLcVSHcoRszvFYsRTyn9b59oO5OJNAUgFi0vlGc2XTKsMDrd/XAAAAAAAAAAAERKVcXI8PffCH3T9ibv7EKZdtGahkLE2cbXJfKU0Q4kR0EpuoCP+7ogg0K/dpo3ZcDxc54cjrgiAAAAAAAAAJAzqipG/Hnhl8U1eW9ppc4pFPUlEHGGURLjQ2LFJOrGUlRaTeBWtJMbMiDd8s6Asxe8NeDpjraN0DkAAAAAAAAAkCuqK0bKtfkL6AJdyrPqo0irNSDm7NERT6RUTtptpDeRuoaPOzkjCF/PbXm33x9KM5ugEgEAAAAAAACAHFJVMdLYe37NN1dabe2VGx8vFwqrQNRZQlHB86nUKtswJ/lUdb0m2s8VKfhKsQya9l3w9oDP0SYAAAAAAAAAIJ9UVYx8OXLp2u+uvVkNre0n9Pnii/sRnCFLaCqoEpVUYi40DaT0VS4pRZhyg9YHkPYfKBbK5PUu13i7RjQrAAAAAAAAAHCQqoqRlsUH1X532c1j3oIHBs6Zd0lJl0/WCNCQDZQf29a834CbQ3FAe29uFpfxb4c6U35ppj49PbCtdYLnt9CIvd+I4Karo10BAAAAAAAAgINUVYzQ5DcieUCpXKLPF7T8qs/A/lsVCsX1IXL3UeTH/xBNVFjQuMSwvd5/WDcXVnKq/AWa5RX1NpoK7Vr7/LuPRgEAAAAAAAAAOaW6YuSTVyN5gO951NzY0NynT+ORHqmn/ZZCH4JXjaMoaiCfSh0VFK91j1a0PJX1HdwC3VKKNJWpV299RO/+ul0MnPwOWRTQNAAAAAAAAAAgp1RXjLy1WXSTYE5z3ujzSp9lW05sGjXnKipDM+IkqkwFrag9/ietoDzvoZIuLascawulmb3ObFV0l98XzQEAAAAAAAAA6oHqipFpi0X6oDZOTX3U1d7oL1f3SZ1IWIZ3CtWRyqS7aRK1PsFTilSTfwRp/RfSqrdyzHRIefr5uZNH/q71k6bobz4WbQwAAAAAAAAAXMRL9GHao6JfPLmoC9dD9G6hlB+rmkIpTfNneyf0WXHOP7SvertW/mKpdF8DlTZWykNAEQAAAAAAAACoI6qbB2z7XrRP0kQLBrZTW2MLaZ+OGdTa9ztaYasOVxDFhQT+iA3tn9PWon5WaFDk3OZEWs9r7dv3aFXUJX8oy6BEhDg4AAAAAAAAAFAfVFeMbPBJxDNvovZWj9qb+ZHFcmu5ud9OXkE/w/+yBKohPTytSHntsWkCtKallKJbyFcbeQXRjzgmAK1L1KfP5jOXWeIjKvPvBxCUIgAAAAAAAABQR1RXjLTH4GUjE84+JT765JXaPyoU6HDSdKffUuitfcxG06Dda6emOIxFKlYha5XK6hau9xUdLb7P/52gig3//cYmPBrtAgAAAAAAAADqheqKkfcHxfdUpal1QV8qKHpAk9q4OLjlKeVRH1RHskjMly96f0kjmgdFqgtQ5Bc9pXYm0tdpTw12VdGgSB/EWbu5w4xF8iiphHYBAAAAAAAAAPVEdcXIbavG+uDZC38o0CsDv/vZMb2Gz7mGsFNNsooB5VPEGpFKo1Ktfyt4+qiOPzioFFGcKU+Vf8XHm8VSpiPeaiP/QxltAgAAAAAAAADqjaIDedDU3nS953lL+r5/LqokIaEr0WL4FGlADU2LKY9u0Jq2czVQh+b/StT3L/PbBl7QUX5R3HzZQNRKcKEBAAAAAAAAgDqk6EQuVMek9DylVR+t9Kn8WxOqJmaRe2WiqOK6VMLRrEdUvpnrcZS7hdZU8L37y546qaXU52unGYk9OxdtAgAAAAAAAADqkaIrGTGL9WdQxcvmIlRNjPoB5ZPq2B6mUFN9qYpCpKGtmX7ItztTKRrscLF9XVZ/bdDFE1uV73/DoKVAcOICAAAAAAAAgDql6GCeLtaKFlOaforqiR7RB4hiRPNPtdiLiCdOqV0Cq+rrS+16N+X8pkJ6ovbpZIkMi1YAAAAAAAAAAGAhnpO5UvRL/v9/oHqiReJrlL02Wui7FP4+HWzcPF+/pBS5rxTRNImovDsXuw2tAAAAAAAAAABAZzxH89Xma+8oUuoXqKKoMNoLVePWK0r3a/D9P2uiR5WiZVwvNefzJs7z/qh/AAAAAAAAAABdUXQ8fxfydL4/T25/Tu4qcbKB0ixAn8o1OdDoFfu29R5b0HojnYkiq5t0wT+kw8QFO84AAAAAAAAAAOgC15UNZaXUL3kufwGqqjaUKrEYQ2sHenE6hq9/tKnc4L5SRCsJtXqT8vX3UfMAAAAAAAAAALqjmI1s6tOVV2jUWv+YtMb+IZZIDBDPYylaetFozdcpWlqRvpY8va38zVduq0UUZ9jX/nhd0kd4pNpR+wAAAAAAAAAAuiMz7ikF5Z3GM95LJVaGcn8LFLcq2StXtCO21xXokAKpF/jHbTNR0I4ilu7yi+X9NJQiAAAAAAAAAACCzH2zklGlVNlvaTu1Vz9/P98vL0DVBZKaWHyQ0n7wGBtartKj+ZKHi436Bv7LsKyUVrd6v5rzYu8D+KcS6h4AAAAAAAAAQBAyoxhZGD9TtdKtbZ+rMfxjM6qvZ6kVlM//H9xaRCt9JDeK5/nHrTMUsLSdW8ap2lfnlOY0ol0AAAAAAAAAAAhMpnZ6EW+QcrtHfkndxnP9ffhPcwleNV1XrOeR9qyCimzI6cGy51/NxwFZKqtWdLQmugi1DgAAAAAAAADAev6c4bz/Ryu9Cs+KX/YUPCe+iaJSWwv5XgCtkadlx5lTSeuHSWKJ6OyompRPUwtU3pszPBZ1DgAAAAAAAAAgDF6mc6/oE/JL27f6/Z5EVXaqVKWodf4cPnZfvZr0WgNb+z3sK/o9/9o3Y8X8tL3XgB0LWt9BMBsCAAAAAAAAABB2Dp31AigqfzavfejuivQjqE4jEyW70FSp2sp2uyM8TX8i8h/pVW7YmDIUTESLSYui15VP6/gNhbe0+SsAAAAAAAAAABAGL/tF6LAW+Jy03ton9UuvUKh7vxpF1WKLKM/Thb2V1s/yLyew5AaVlZ+hcikqaO8a0rQ9/zoD+hAAAAAAAAAAALXi5akwPHE+v3VB83GkVHt9Vqdsz1vuyrFE/rS5xOIo+t6t/PMyGSxcubnY9vsmv3g0l+MTvLoAAAAAAAAAAKIgX4oRpfx5sz6/kpS3P/86p/5CT0jk1I5NjanidNLBQNL6Eirr+/lvB+usBeRQCw/qWK380zTiiQAAAAAAAAAAiJBcKUY6FAGFjiKN599WIZ+erY9K9Dq2aKHObjGaehe0PkaTnsz/8GP+S69Mlk3RW1T29tTKv1L25QUAAAAAAAAAAKKdU+cUTfRpA9EO/OPdpJRWSuW2oO1eiQokipGOMnpa6+/26d/vkUK5/Bf+eaXMFkzRC21T+3+XfHUnXlUAAAAAAAAAAHHg5bpwimbz5HpfXfb/lN9SKmorLBA9gqe03oL/cJ0muqfY0LBhhmOTaqW8CVrpjfzWwgfwngEAAAAAAAAAEBe5VowYxUAraf3jLz77bBvlqemUM8uRlgF9qVDstRyRusoj/wH+06GcCr7vZ7K+OLUqrY4kVdiHfy3hFQUAAAAAAAAAECdefZRSUamlZZJHajNF+vU8Fa2pZf75fdoKz5DSR/KvjVkuS0HT+x75O/GP15HWUIoAAAAAAAAAAIhfZVAXpRRThIJHSnnvtMz7chvS3oTigHZNfvatRxraWk+jcmlE9itJPV/UeusG35+E1xIAAAAAAAAAQFJ4dVVaReSXytNVo957/suDz1KN/kxV0JkukvY8CciRzbybfCvy/6EVbcU/TtV4JwEAAAAAAAAAJIhXdyXmybhq8MuzHx/5Gz5uwn95Fc0ghWqgjkAon/iatuNfjuJf50MqAAAAAAAAAACSxqvr0hf9KbMmLrV+oZd/B5pCsmjSkxq03pR/fAjSAAAAAAAAAACQFnWtGBFPjtLshlal1IHK9/YkRdPQJGLnc4/0WfPKA3Zi8b8PcQAAAAAAAAAASBMPIiBSmto8X91ZVmoj8tXE4sC2XARmdQ/9YkMTba1J/1rrQqsIHgAAAAAAAAAASBMoRmS6riRpOX6gGvUec18YerrXUP6YMG+PUMj6ckV6c25xr3T8LnonyBcAAAAAAAAAQMpAMbKoQBr98pynRpzv9/E21p53t9dUhlBq47WCKq1Lvj6eSC+AMgQAAAAAAAAAgFN6AIiga8qNxY90Ue3WPq3XL/jXeV6vMiwcrFEXK19vqMh/SXeYiMA9CQAAAAAAAACAW0AxUg1RgniaWj/pc74qlka1fdLnDipAMxKQJwrFhq1ZiD/lnxdAIQIAAAAAAAAAwFWgGAmAKvozWj7qu58m/2j+tR0S6UJGXofSqIXTub7W23rKewRSAQAAAAAAAADgOlCMBEWT+NJc01gurqyJHqooAyAWIxuJXvtCoai3ZZn8in9r0/A7AgAAAAAAAACQATC1txaYeq+52LZTmfwdtaZ36lkWRvUxnRr0Txe8PnAr1aCfIkRi+RYFVYIQAAAAAAAAAMDZeT6wVgb4ym9XDf59C97qvxEV9J8khIbXu+52rykXlbqTS76BKuiLdZs3jxR0Ios2lqLXRsObpkIWAAAAAAAAAOAoUIyEmvBWgonq9sIspfRJyldbt7zf986Of8m7cqBS9Ce5qIc2KLU3//wRbES6aiNE/Rpn0rDGDwkKIwAAAAAAAABwFyhGopgDt3uPtE/tvyf/OEZr9anK4SYsnu5oKnMLHp3ieWpb/vlfPN33UftdNQiifg2zaUDjF0TKJ63xmgEAAAAAAACAs/NdiCAqFClFN7Z82HfDUpnO4D8sUDo3lgJtLYW2m3jGv5Gn1SX8eyvqu2sKqp2G9PqABhank08FKEUAAAAAAAAAwHEwa4sSRaRL3sfldjpbabWeVt4tX/1DBgtTVO2i2XmS05YtxdZDNOnX4RRSnQKVaGjT+9ToLaCSbiStFYQCAAAAAAAAAI4DxUgcVObDb7b077c/+XpPotKDJPFHvP9n725C46qiAI6fc9+bSTJtmsYPCkJduhXsohVdVCu6q4iboi50JSgudCm4deFGQdGFm+JOlBREFBQqQRctFFFBxSK2hbShkVpt02Y+3r3Hc2dio8WWZLRpJu//gzOZueHNx313Bs7hvnttZD6ASvrmYnXrs/5RHvCGowyVa8intOXRFJluzUvQ5Ke8FDbnAQAAAIDRQLZ7wxJmEyty99pHGqqHVeRpS3ra0sZdliO0qlwTOW8SX1SxPZd60++qpi4n8zq2eZzx+MljwiRZQZ8AAAAAwAihMHIjXZk0oElU3uucau0KY42XvOG3Dfg+F9s/T74jKdwjkt6QvI6IChMfrtdnTY95j1mP6E2RrxMAAAAAjBoyufWiJlbp2dAYf90s7fKWg/3mmz+DJFqQjxtBdy+dmHzOkpzkZK1Cnily0eMLjzynhuVEAAAAAGAkURhZb9YvhJz0O89ICHurZvOorPO8DF15uW/FdL8G2+95/Q+cnFUa8zjh8alHm+4AAAAAgFFGYeQmMpXZsSLcp6YPadCv12PagYYgJuGYij3ur3+vN33iDcYVM6s5YTJYaHXB4yuPHl0CAAAAAKNu6MKIFvbfo7SVhLOmipSi/zlclI3dRbADfv97Uf1feyTvhqOa9xK2M7Hbfv5ynLpfxWb8X0u17XgbzJzRtX5bclHkM6EoAgAAAACbRDnsgXccOC5xaejD+ynpxO0iZ7+8TYqJ2N/FpY5rfa6k5lp5ov6+qXwglvaphJe9S/bmeobmHW5Uh3lyCeNRqsvhR7P4WqtZfHhhqbtozfpNFLLlwZU3Ii5DT6Yav0qzWJSuteSP7o7VPUnD4wg/GgAAAACwmQxd2SinuqKN4RcOzQWBckuQ7Q/OS+f3STFLEj17DVrXrVBsOTRJSp9LKA6Pt+zRzpI8ZSE8NtTFLoUd686NHzw/ecvb03rKQr4OREPtFgrNPRf8JvpNJdG7pSdbm21J3lal5tqeLPKjAQAAAACbydCFkdQp+jF8sqqS2irVhcJzfs/UC38cTUL/KpKaL30yKFzE5pjNdNoy09mydc/Y4uIL3vbEtQ4JKUml/cJS3hp41jv4TX94qLcwLrbNz5NqrcpNuhx5aAUrZHunK+cmGlJZ5a0+5pKHJB97LLMDAAAAAHW2MbLCv2fseWYEK4EOumJ5Qo4FPWKiT2qyu/3hqx6/XH1lTSzLuUYIb4nKI6q6z5sO/aNKUBN/fdRcEMmTO0IvSZmChDQYZ2p1nZEEAAAAAPg35cZ7S9q/rMakECWHXc7yr9z7Lof3yyuh1Luqnu1Qy2urxnMLO3cev3PudOfSWhcU3Vz942PH+lWRWPoIqvKMppg33RmsMQIAAAAAwFX+FGAAIvzTd/ZB68QAAAAASUVORK5CYII=\" alt=\"Logo\">\n");
    printf ("<div class=\"des\">\n");
    printf ("<p><a href=\"//github.com/dani-garcia/vaultwarden\" target=\"_blank\">Vaultwarden</a>服务器全局配置</p>\n");
    printf ("</div>\n");
    printf ("<form method=\"post\" action=\"\">\n");
    printf ("<textarea id=\"textcontent\" name=\"textcontent\">\n");
    Content();
    printf ("</textarea>\n");
    printf ("<br>\n");
    printf ("<input type=\"submit\" name=\"Submit\" class=\"button\" value=\"保存\" />\n");
    printf ("<button type=\"button\" class=\"button\" onclick=\"toMantPage()\">管理</button>\n");
    printf ("</form>\n");
    printf ("</div>\n");
    printf ("<script>\n");
    printf ("var editor = CodeMirror.fromTextArea(document.getElementById(\"textcontent\"), {\n");
    printf ("lineNumbers: true,\n");
    printf ("mode: \"shell\",\n");
    printf ("theme: \"default\",\n");
    printf ("lineWrapping: true\n");
    printf ("});\n");
    printf ("var prol = window.location.protocol;\n");
    printf ("var domain = document.domain;\n");
    GetWebPort();
    printf ("function toMantPage() {\n");
    printf ("window.open(url, '_blank');\n");
    printf ("}\n");

    printf ("function showSavingMessage() {\n");
    printf ("var savingLayer = document.createElement('div');\n");
    printf ("savingLayer.id = 'saving-layer';\n");
    printf ("savingLayer.style.position = 'fixed';\n");
    printf ("savingLayer.style.top = '0';\n");
    printf ("savingLayer.style.left = '0';\n");
    printf ("savingLayer.style.width = '100%';\n");
    printf ("savingLayer.style.height = '100%';\n");
    printf ("savingLayer.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';\n");
    printf ("savingLayer.style.zIndex = '9999';\n");
    printf ("var message = document.createElement('p');\n");
    printf ("message.innerHTML = '正在处理，请稍候...';\n");
    printf ("message.style.position = 'absolute';\n");
    printf ("message.style.top = '50%';\n");
    printf ("message.style.left = '50%';\n");
    printf ("message.style.transform = 'translate(-50%, -50%)';\n");
    printf ("message.style.color = '#fff';\n");
    printf ("message.style.fontSize = '24px';\n");
    printf ("message.style.textAlign = 'center';\n");
    printf ("message.style.margin = '0';\n");
    printf ("savingLayer.appendChild(message);\n");
    printf ("document.body.appendChild(savingLayer);\n");
    printf ("}\n");
    printf ("var showSavingLayer = false;\n");
    printf ("window.addEventListener('load', function() {\n");
    printf ("if (showSavingLayer) {\n");
    printf ("showSavingMessage();\n");
    printf ("}\n");
    printf ("});\n");

    printf ("document.querySelector('form').addEventListener('submit', function(event) {\n");
    printf ("showSavingLayer = true;\n");
    printf ("showSavingMessage();\n");
    printf ("});\n");

    printf ("</script>\n");
    printf ("</body>\n");
    printf ("</html>\n");
    return 0;
}

int main(int argc, char **argv) {
    char user[256];
    printf("Content-type: text/html\n\n");
    if (IsUserLogin(user, sizeof(user)) == 1) {
        WebPage();
    } else {
        printf("<head> <meta charset=\"UTF-8\"> </head>\n");
        printf("用户未登录。\n");
    }
    return 0;
}

